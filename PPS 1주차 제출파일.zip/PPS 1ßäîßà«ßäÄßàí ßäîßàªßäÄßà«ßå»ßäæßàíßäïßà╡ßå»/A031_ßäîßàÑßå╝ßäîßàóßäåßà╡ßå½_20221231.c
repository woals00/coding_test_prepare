// pps a31번 백준 2163번

// 2022.12.31 토

#include <stdio.h>

int main()
{
    int n,m;
    scanf("%d %d", &n, &m);
    int count = n * m - 1;
    printf("%d", count);
    return 0;
}